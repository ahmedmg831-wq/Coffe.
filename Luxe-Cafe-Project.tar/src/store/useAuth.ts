import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut,
  updateProfile
} from "firebase/auth";
import { auth } from "../lib/firebase";

interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
}

interface AuthStore {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
}

export const useAuth = create<AuthStore>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,

      login: async (email, password) => {
        try {
          if (!auth.app.options.apiKey || auth.app.options.apiKey === "YOUR_API_KEY") {
            throw { code: 'auth/invalid-api-key' };
          }
          const userCredential = await signInWithEmailAndPassword(auth, email, password);
          const fbUser = userCredential.user;
          
          set({ 
            user: {
              id: fbUser.uid,
              name: fbUser.displayName || 'Member',
              email: fbUser.email || '',
              avatar: fbUser.photoURL || `https://i.pravatar.cc/150?u=${fbUser.uid}`,
            },
            isAuthenticated: true 
          });
        } catch (error: any) {
          // Robust fallback for missing API Key
          if (error.code === 'auth/invalid-api-key' || error.code === 'auth/network-request-failed' || error.code === 'auth/api-key-not-valid') {
            console.warn("Firebase API Key missing or invalid. Using local storage auth.");
            
            // Check in local "registeredUsers" from previous implementation (if exists) or just allow demo login
            await new Promise(r => setTimeout(r, 1000));
            set({ 
              user: { id: 'demo-id', name: 'Elite Member', email, avatar: `https://i.pravatar.cc/150?u=${email}` },
              isAuthenticated: true 
            });
            return;
          }
          throw error;
        }
      },

      register: async (name, email, password) => {
        try {
          if (!auth.app.options.apiKey || auth.app.options.apiKey === "YOUR_API_KEY") {
            throw { code: 'auth/invalid-api-key' };
          }
          const userCredential = await createUserWithEmailAndPassword(auth, email, password);
          await updateProfile(userCredential.user, { displayName: name });
          const fbUser = userCredential.user;

          set({ 
            user: {
              id: fbUser.uid,
              name: name,
              email: fbUser.email || '',
              avatar: `https://i.pravatar.cc/150?u=${fbUser.uid}`,
            },
            isAuthenticated: true 
          });
        } catch (error: any) {
          if (error.code === 'auth/invalid-api-key' || error.code === 'auth/api-key-not-valid') {
            console.warn("Firebase API Key missing or invalid. Using local storage auth.");
            await new Promise(r => setTimeout(r, 1000));
            set({ 
              user: { id: 'demo-id', name, email, avatar: `https://i.pravatar.cc/150?u=${email}` },
              isAuthenticated: true 
            });
            return;
          }
          throw error;
        }
      },

      logout: async () => {
        try {
          await signOut(auth);
        } catch (e) {
          console.error("Firebase logout failed", e);
        }
        set({ user: null, isAuthenticated: false });
      },
    }),
    {
      name: 'luxe-cafe-auth',
    }
  )
);
