import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../store/useCart';
import { useAuth } from '../store/useAuth';
import { Copy, Check, Upload, ArrowLeft, Building2, CreditCard } from 'lucide-react';
import toast from 'react-hot-toast';
import { db, storage, isFirebaseConfigured } from '../lib/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';

const banks = [
  { id: 'bank1', name: 'Al Rajhi Bank', iban: 'SA1234567890123456789012', owner: 'Luxe Café Group' },
  { id: 'bank2', name: 'SNB (AlAhli)', iban: 'SA9876543210987654321098', owner: 'Luxe Café Group' },
  { id: 'bank3', name: 'Riyad Bank', iban: 'SA4567891234567891234567', owner: 'Luxe Café Group' },
];

const Checkout = () => {
  const { items, totalPrice, clearCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [banks, setBanks] = useState<any[]>([]);
  const [selectedBank, setSelectedBank] = useState<any>(null);
  const [copied, setCopied] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const savedSettings = JSON.parse(localStorage.getItem('luxe-site-settings') || '{}');
    const availableBanks = savedSettings.banks || [
      { id: 'default', name: 'Al Rajhi Bank', iban: 'SA1234567890123456789012', owner: 'Luxe Café Group' }
    ];
    setBanks(availableBanks);
    setSelectedBank(availableBanks[0]);
  }, []);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedBank.iban);
    setCopied(true);
    toast.success('IBAN copied to clipboard');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return toast.error('Please upload your transfer receipt');
    if (!user) return navigate('/auth');

    setIsSubmitting(true);
    const toastId = toast.loading('Processing your order...');

    try {
      let receiptUrl = URL.createObjectURL(file);
      
      const orderData = {
        id: Math.random().toString(36).substr(2, 9),
        userId: user.id,
        userName: user.name,
        userEmail: user.email,
        items: items.map(i => ({ name: i.name, quantity: i.quantity, price: i.price })),
        total: totalPrice(),
        bankName: selectedBank.name,
        receiptUrl: receiptUrl,
        status: 'pending',
        createdAt: new Date().toISOString()
      };

      if (isFirebaseConfigured) {
        // Real Firebase Flow
        const storageRef = ref(storage, `receipts/${Date.now()}_${user.id}`);
        await uploadBytes(storageRef, file);
        receiptUrl = await getDownloadURL(storageRef);
        await addDoc(collection(db, "orders"), { ...orderData, receiptUrl, createdAt: serverTimestamp() });
      } else {
        // Local Flow
        const localOrders = JSON.parse(localStorage.getItem('luxe-orders') || '[]');
        localStorage.setItem('luxe-orders', JSON.stringify([...localOrders, orderData]));
      }

      toast.success('Order placed successfully! We will verify your payment soon.', { id: toastId });
      clearCart();
      navigate('/');
    } catch (error) {
      toast.error('Error placing order. Please try again.', { id: toastId });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center p-8">
        <h2 className="text-3xl font-serif mb-6">Your selection is empty</h2>
        <button onClick={() => navigate('/')} className="btn-gold">Back to Experience</button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black pt-32 pb-20 px-8">
      <div className="max-w-5xl mx-auto">
        <button onClick={() => navigate('/')} className="flex items-center gap-2 text-gray-400 hover:text-white mb-12 group">
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          Back to Selection
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          <div className="space-y-10">
            <div>
              <h1 className="text-4xl font-serif font-bold mb-4">Complete Your <span className="gold-gradient">Order</span></h1>
              <p className="text-gray-400">Please transfer the total amount to one of our official bank accounts below.</p>
            </div>

            <div className="space-y-4">
              <label className="text-sm uppercase tracking-widest text-gold-500 font-bold">Select Your Bank</label>
              <div className="grid grid-cols-1 gap-3">
                {banks.map((bank) => (
                  <button
                    key={bank.id}
                    onClick={() => setSelectedBank(bank)}
                    className={`flex items-center justify-between p-5 rounded-2xl border transition-all ${
                      selectedBank?.id === bank.id ? 'border-gold-500 bg-gold-500/10' : 'border-white/10 bg-white/5 hover:bg-white/10'
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <Building2 className={selectedBank?.id === bank.id ? 'text-gold-500' : 'text-gray-500'} />
                      <span className="font-bold">{bank.name}</span>
                    </div>
                    {selectedBank?.id === bank.id && <Check className="text-gold-500" />}
                  </button>
                ))}
              </div>
            </div>

            {selectedBank && (
              <motion.div 
                key={selectedBank.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="glass-card p-8 space-y-6"
              >
                <div>
                  <p className="text-xs uppercase tracking-[0.2em] text-gold-500 mb-1 font-bold">Bank Name</p>
                  <p className="text-xl font-bold">{selectedBank.name}</p>
                </div>
                <div>
                  <p className="text-xs uppercase tracking-[0.2em] text-gray-500 mb-1">Account Holder</p>
                  <p className="text-lg">{selectedBank.owner}</p>
                </div>
                <div>
                  <p className="text-xs uppercase tracking-[0.2em] text-gray-500 mb-1">IBAN Number</p>
                  <div className="flex items-center justify-between bg-black/40 p-4 rounded-xl border border-white/5">
                    <span className="font-mono text-lg break-all">{selectedBank.iban}</span>
                    <button onClick={handleCopy} className="p-2 hover:bg-white/10 rounded-lg transition-colors text-gold-500">
                      {copied ? <Check className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </div>

          {/* Step 2: Summary & Receipt */}
          <div className="space-y-8">
            <div className="glass-card p-8">
              <h3 className="text-xl font-serif font-bold mb-6 border-b border-white/10 pb-4">Order Summary</h3>
              <div className="space-y-4 mb-6">
                {items.map((item) => (
                  <div key={item.id} className="flex justify-between text-sm">
                    <span className="text-gray-400">{item.name} x {item.quantity}</span>
                    <span className="font-bold">${(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
              </div>
              <div className="flex justify-between text-2xl font-serif border-t border-white/10 pt-4">
                <span>Total</span>
                <span className="text-gold-500 font-bold">${totalPrice().toFixed(2)}</span>
              </div>
            </div>

            <form onSubmit={handleSubmitOrder} className="space-y-6">
              <div className="space-y-4">
                <label className="text-sm uppercase tracking-widest text-gold-500 font-bold">Upload Transfer Receipt</label>
                <div className="relative group">
                  <input 
                    type="file" 
                    accept="image/*"
                    onChange={(e) => setFile(e.target.files?.[0] || null)}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                  />
                  <div className={`border-2 border-dashed rounded-2xl p-10 flex flex-col items-center justify-center transition-all ${
                    file ? 'border-gold-500 bg-gold-500/5' : 'border-white/10 bg-white/5 group-hover:border-gold-500/50'
                  }`}>
                    <Upload className={`w-10 h-10 mb-4 ${file ? 'text-gold-500' : 'text-gray-500'}`} />
                    <p className="text-sm text-center">
                      {file ? <span className="text-gold-500 font-bold">{file.name}</span> : 'Click or drag and drop your receipt image here'}
                    </p>
                  </div>
                </div>
              </div>

              <button 
                type="submit" 
                disabled={isSubmitting}
                className="w-full btn-gold py-6 text-xl shadow-[0_20px_40px_rgba(212,175,55,0.15)] disabled:opacity-50 flex justify-center items-center gap-3"
              >
                {isSubmitting ? <div className="w-6 h-6 border-2 border-black border-t-transparent rounded-full animate-spin" /> : <CreditCard />}
                {isSubmitting ? 'Processing...' : 'Confirm Order'}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;
