import React, { useEffect, useState } from 'react';
import { Coffee, ArrowRight, Instagram, MessageCircle, Ghost } from 'lucide-react';

const Footer = () => {
  const [settings, setSettings] = useState({
    whatsapp: '',
    instagram: '',
    snapchat: ''
  });

  useEffect(() => {
    const savedSettings = JSON.parse(localStorage.getItem('luxe-site-settings') || '{}');
    setSettings({
      whatsapp: savedSettings.whatsapp || '',
      instagram: savedSettings.instagram || '',
      snapchat: savedSettings.snapchat || ''
    });
  }, []);

  return (
    <footer className="bg-black pt-24 pb-12 px-8 border-t border-white/5">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-16 mb-20">
          <div className="space-y-6">
            <div className="flex items-center gap-2">
              <Coffee className="text-gold-500 w-8 h-8" />
              <span className="text-2xl font-serif font-bold tracking-tighter">LUXE CAFÉ</span>
            </div>
            <p className="text-gray-400 leading-relaxed">
              Crafting extraordinary coffee experiences for those who appreciate the finer things in life.
            </p>
            <div className="flex gap-4 pt-4">
              {settings.whatsapp && (
                <a href={`https://wa.me/${settings.whatsapp.replace(/\+/g, '')}`} target="_blank" rel="noreferrer" className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center hover:border-gold-500 hover:text-gold-500 transition-all bg-white/5">
                  <MessageCircle className="w-5 h-5" />
                </a>
              )}
              {settings.instagram && (
                <a href={`https://instagram.com/${settings.instagram}`} target="_blank" rel="noreferrer" className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center hover:border-gold-500 hover:text-gold-500 transition-all bg-white/5">
                  <Instagram className="w-5 h-5" />
                </a>
              )}
              {settings.snapchat && (
                <a href={`https://snapchat.com/add/${settings.snapchat}`} target="_blank" rel="noreferrer" className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center hover:border-gold-500 hover:text-gold-500 transition-all bg-white/5">
                  <Ghost className="w-5 h-5" />
                </a>
              )}
            </div>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-8 uppercase tracking-widest">Navigation</h4>
            <ul className="space-y-4 text-gray-400">
              <li><a href="#hero" className="hover:text-gold-500 transition-colors">Home</a></li>
              <li><a href="#features" className="hover:text-gold-500 transition-colors">Our Story</a></li>
              <li><a href="#products" className="hover:text-gold-500 transition-colors">Collections</a></li>
              <li><a href="#reviews" className="hover:text-gold-500 transition-colors">Testimonials</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-8 uppercase tracking-widest">Support</h4>
            <ul className="space-y-4 text-gray-400">
              <li><a href="#" className="hover:text-gold-500 transition-colors">Shipping Policy</a></li>
              <li><a href="#" className="hover:text-gold-500 transition-colors">Wholesale</a></li>
              <li><a href="#" className="hover:text-gold-500 transition-colors">Sustainability</a></li>
              <li><a href="#" className="hover:text-gold-500 transition-colors">Contact</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-8 uppercase tracking-widest">Newsletter</h4>
            <p className="text-gray-400 mb-6">Join our elite circle for exclusive access to rare harvests.</p>
            <form className="relative">
              <input 
                type="email" 
                placeholder="Email Address" 
                className="w-full bg-white/5 border border-white/10 rounded-full px-6 py-4 focus:outline-none focus:border-gold-500 transition-colors"
              />
              <button className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 bg-gold-500 rounded-full flex items-center justify-center text-black hover:bg-gold-400 transition-colors">
                <ArrowRight className="w-5 h-5" />
              </button>
            </form>
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center pt-12 border-t border-white/5 gap-6 text-sm text-gray-500">
          <p>© 2026 LUXE CAFÉ. All rights reserved.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
