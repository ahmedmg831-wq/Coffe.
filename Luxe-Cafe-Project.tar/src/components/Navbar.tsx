import React from 'react';
import { Coffee, ShoppingBag, User, LogOut, Settings } from 'lucide-react';
import { useCart } from '../store/useCart';
import { useAuth } from '../store/useAuth';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';

const Navbar = () => {
  const { toggleCart, items } = useCart();
  const { isAuthenticated, user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    toast.success('Signed out successfully');
    navigate('/');
  };

  return (
    <nav className="fixed top-0 left-0 w-full z-50 flex justify-between items-center px-8 py-6 backdrop-blur-md bg-black/20 border-b border-white/5">
      <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate('/')}>
        <Coffee className="text-gold-500 w-8 h-8" />
        <span className="text-2xl font-serif font-bold tracking-tighter">LUXE CAFÉ</span>
      </div>
      
      <div className="hidden md:flex items-center gap-8 text-sm uppercase tracking-widest font-medium">
        <a href="#hero" className="hover:text-gold-500 transition-colors">Home</a>
        <a href="#features" className="hover:text-gold-500 transition-colors">Experience</a>
        <a href="#products" className="hover:text-gold-500 transition-colors">Collection</a>
        <a href="#reviews" className="hover:text-gold-500 transition-colors">Reviews</a>
      </div>

      <div className="flex items-center gap-6">
        <button 
          onClick={toggleCart}
          className="relative p-2 hover:bg-white/5 rounded-full transition-all"
        >
          <ShoppingBag className="w-6 h-6" />
          {items.length > 0 && (
            <span className="absolute top-0 right-0 w-5 h-5 bg-gold-500 text-black text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-black">
              {items.reduce((acc, item) => acc + item.quantity, 0)}
            </span>
          )}
        </button>

        {isAuthenticated ? (
          <div className="flex items-center gap-4">
            {user?.email === 'omarmg831@gmail.com' && (
              <button 
                onClick={() => navigate('/admin')}
                className="p-2 hover:bg-gold-500/10 hover:text-gold-500 rounded-full transition-all text-gold-500"
                title="Admin Dashboard"
              >
                <Settings className="w-5 h-5" />
              </button>
            )}
            <div className="flex items-center gap-3 bg-white/5 pl-2 pr-4 py-1.5 rounded-full border border-white/10">
              <img src={user?.avatar} alt={user?.name} className="w-8 h-8 rounded-full border border-gold-500/50" />
              <span className="text-xs font-bold uppercase tracking-widest text-gray-300">{user?.name.split(' ')[0]}</span>
            </div>
            <button 
              onClick={handleLogout}
              className="p-2 hover:bg-red-500/10 hover:text-red-500 rounded-full transition-all text-gray-400"
              title="Logout"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        ) : (
          <button 
            onClick={() => navigate('/auth')}
            className="flex items-center gap-2 text-sm uppercase tracking-widest font-bold hover:text-gold-500 transition-colors"
          >
            <User className="w-5 h-5" />
            <span className="hidden sm:inline">Join Elite</span>
          </button>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
