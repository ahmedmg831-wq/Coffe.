import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';

const Hero = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(textRef.current?.children || [], {
        y: 100,
        opacity: 0,
        duration: 1.2,
        stagger: 0.2,
        ease: 'power4.out',
      });

      gsap.from(imageRef.current, {
        scale: 0.8,
        opacity: 0,
        duration: 1.5,
        delay: 0.5,
        ease: 'power3.out',
      });

      // Floating animation for the 3D coffee cup placeholder
      gsap.to(imageRef.current, {
        y: -20,
        duration: 2,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut',
      });
    }, heroRef);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={heroRef}
      id="hero" 
      className="relative min-h-screen flex flex-col md:flex-row items-center justify-center px-8 pt-20 overflow-hidden"
    >
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gold-500/10 blur-[120px] rounded-full -z-10" />

      <div ref={textRef} className="flex-1 text-center md:text-left z-10">
        <h2 className="text-gold-500 font-serif italic text-2xl mb-4">The Art of Brewing</h2>
        <h1 className="text-6xl md:text-8xl font-serif font-bold leading-tight mb-6">
          Elevate Your <br />
          <span className="gold-gradient">Senses</span>
        </h1>
        <p className="text-gray-400 text-lg md:text-xl max-w-xl mb-10 leading-relaxed">
          Experience the pinnacle of coffee craftsmanship. Our rare beans are hand-selected from the world's most exclusive estates.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
          <button className="btn-gold">Explore Collection</button>
          <button className="px-8 py-4 rounded-full border border-white/20 hover:bg-white/5 transition-all font-bold">
            Watch Story
          </button>
        </div>
      </div>

      <div ref={imageRef} className="flex-1 relative mt-12 md:mt-0">
        <div className="relative w-full aspect-square max-w-[500px] mx-auto">
          {/* Using a high-quality coffee cup image placeholder */}
          <img 
            src="https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?q=80&w=1000&auto=format&fit=crop" 
            alt="Luxury Coffee Cup"
            className="w-full h-full object-cover rounded-3xl shadow-2xl rotate-3 hover:rotate-0 transition-transform duration-700"
          />
          <div className="absolute -bottom-6 -right-6 glass-card p-6 animate-bounce">
            <p className="text-gold-500 font-bold">New Arrival</p>
            <p className="text-sm text-gray-400">Ethiopian Yirgacheffe</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
