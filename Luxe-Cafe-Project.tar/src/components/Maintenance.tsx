import React from 'react';
import { motion } from 'framer-motion';
import { Coffee, Hammer, Clock } from 'lucide-react';

const Maintenance = () => {
  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-8 relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gold-500/10 blur-[120px] rounded-full" />
      
      <div className="max-w-2xl text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <div className="flex justify-center mb-12">
            <div className="relative">
              <Coffee className="w-24 h-24 text-gold-500" />
              <motion.div 
                animate={{ rotate: 360 }}
                transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                className="absolute -top-4 -right-4"
              >
                <Hammer className="w-10 h-10 text-gold-500/50" />
              </motion.div>
            </div>
          </div>

          <h1 className="text-5xl md:text-7xl font-serif font-bold mb-6">
            Refining the <br />
            <span className="gold-gradient">Experience</span>
          </h1>
          
          <p className="text-xl text-gray-400 mb-12 leading-relaxed">
            We are currently enhancing our digital boutique to better serve your luxury coffee needs. 
            Luxe Café will return shortly with even more exquisite features.
          </p>

          <div className="flex items-center justify-center gap-3 text-gold-500 bg-gold-500/5 border border-gold-500/20 py-4 px-8 rounded-full inline-flex">
            <Clock className="w-5 h-5 animate-pulse" />
            <span className="font-bold uppercase tracking-widest text-sm">Estimated downtime: 2 hours</span>
          </div>

          <div className="mt-16 flex justify-center gap-6">
            <div className="w-2 h-2 rounded-full bg-gold-500 animate-bounce" />
            <div className="w-2 h-2 rounded-full bg-gold-500 animate-bounce [animation-delay:0.2s]" />
            <div className="w-2 h-2 rounded-full bg-gold-500 animate-bounce [animation-delay:0.4s]" />
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Maintenance;
