import React, { useEffect, useRef } from 'react';
import { Leaf, Truck, Award, Zap } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const features = [
  {
    icon: <Leaf className="w-8 h-8 text-gold-500" />,
    title: "Premium Coffee Beans",
    description: "Ethically sourced from the highest altitudes of the world's finest coffee regions."
  },
  {
    icon: <Truck className="w-8 h-8 text-gold-500" />,
    title: "Fast Delivery",
    description: "Freshly roasted and delivered to your doorstep within 48 hours of your order."
  },
  {
    icon: <Zap className="w-8 h-8 text-gold-500" />,
    title: "Organic Ingredients",
    description: "100% natural, pesticide-free beans grown with respect for the environment."
  },
  {
    icon: <Award className="w-8 h-8 text-gold-500" />,
    title: "Award-winning Taste",
    description: "Recognized globally for its complex flavor profile and smooth finish."
  }
];

const Features = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".feature-card", {
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top 80%",
        },
        y: 60,
        opacity: 0,
        duration: 0.8,
        stagger: 0.2,
        ease: "power3.out"
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} id="features" className="py-24 px-8 relative overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-20">
          <h2 className="text-gold-500 font-serif italic text-xl mb-4">Why Choose Us</h2>
          <h3 className="text-4xl md:text-5xl font-serif font-bold">The Gold Standard of Coffee</h3>
        </div>

        <div ref={cardsRef} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="feature-card glass-card p-8 hover:bg-white/10 transition-colors duration-500 group"
            >
              <div className="mb-6 transform group-hover:scale-110 transition-transform duration-500">
                {feature.icon}
              </div>
              <h4 className="text-xl font-bold mb-4">{feature.title}</h4>
              <p className="text-gray-400 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
