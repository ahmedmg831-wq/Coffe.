import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const faqs = [
  {
    question: "How do you source your beans?",
    answer: "We work directly with small-batch farmers in Ethiopia, Colombia, and Indonesia. We pay 50% above fair trade prices to ensure the highest quality and sustainable practices."
  },
  {
    question: "What is the freshness guarantee?",
    answer: "Every bag is roasted to order. We ship within 24 hours of roasting, and our specialized valved packaging ensures peak freshness for up to 6 months unopened."
  },
  {
    question: "Do you offer international shipping?",
    answer: "Yes, we ship to over 50 countries worldwide via premium express couriers to maintain product integrity during transit."
  },
  {
    question: "Can I cancel my subscription?",
    answer: "Absolutely. Our 'Membership' is flexible. You can pause, skip, or cancel your subscription at any time through your account dashboard with no hidden fees."
  }
];

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section className="py-24 px-8 bg-neutral-950">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-gold-500 font-serif italic text-xl mb-4">Questions</h2>
          <h3 className="text-4xl font-serif font-bold">Frequently Asked</h3>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div key={index} className="border-b border-white/10">
              <button 
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full py-6 flex justify-between items-center text-left hover:text-gold-500 transition-colors"
              >
                <span className="text-xl font-medium">{faq.question}</span>
                <ChevronDown className={`w-6 h-6 transition-transform duration-300 ${openIndex === index ? 'rotate-180 text-gold-500' : ''}`} />
              </button>
              
              <AnimatePresence>
                {openIndex === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <p className="pb-6 text-gray-400 leading-relaxed">
                      {faq.answer}
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;
