import React from 'react';
import { Star, Quote } from 'lucide-react';

const reviews = [
  {
    name: "James Anderson",
    role: "Coffee Connoisseur",
    content: "The flavor profile of the Midnight Velvet is unlike anything I've ever experienced. Truly a masterpiece of roasting.",
    rating: 5,
    avatar: "https://i.pravatar.cc/150?u=james"
  },
  {
    name: "Elena Rodriguez",
    role: "Lifestyle Blogger",
    content: "Not only is the coffee exceptional, but the packaging and delivery experience also feel incredibly premium.",
    rating: 5,
    avatar: "https://i.pravatar.cc/150?u=elena"
  },
  {
    name: "Marcus Thorne",
    role: "Hotelier",
    content: "We serve Luxe Café in all our executive suites. Our guests constantly ask where they can buy it for themselves.",
    rating: 5,
    avatar: "https://i.pravatar.cc/150?u=marcus"
  }
];

const Reviews = () => {
  return (
    <section id="reviews" className="py-24 px-8 relative">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-gold-500 font-serif italic text-xl mb-4">Testimonials</h2>
          <h3 className="text-4xl md:text-5xl font-serif font-bold">What Our Members Say</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {reviews.map((review, index) => (
            <div key={index} className="glass-card p-10 relative group">
              <Quote className="absolute top-6 right-6 w-12 h-12 text-gold-500/10 group-hover:text-gold-500/20 transition-colors" />
              
              <div className="flex gap-1 mb-6">
                {[...Array(review.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-gold-500 text-gold-500" />
                ))}
              </div>
              
              <p className="text-lg text-gray-300 mb-8 italic leading-relaxed">
                "{review.content}"
              </p>
              
              <div className="flex items-center gap-4">
                <img 
                  src={review.avatar} 
                  alt={review.name} 
                  className="w-12 h-12 rounded-full grayscale group-hover:grayscale-0 transition-all duration-500"
                />
                <div>
                  <h4 className="font-bold">{review.name}</h4>
                  <p className="text-sm text-gray-500">{review.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Reviews;
