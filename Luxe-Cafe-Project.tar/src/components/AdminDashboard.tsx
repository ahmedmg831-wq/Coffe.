import React, { useEffect, useState } from 'react';
import { useAuth } from '../store/useAuth';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  LayoutDashboard, 
  ShoppingBag, 
  Users, 
  CheckCircle, 
  XCircle, 
  Clock, 
  ExternalLink,
  ArrowLeft,
  Coffee,
  Plus,
  Trash2,
  Upload,
  Package,
  Settings
} from 'lucide-react';
import { db, storage, isFirebaseConfigured } from '../lib/firebase';
import { collection, query, orderBy, onSnapshot, doc, updateDoc, addDoc, deleteDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import toast from 'react-hot-toast';

const AdminDashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [orders, setOrders] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'orders' | 'products' | 'settings'>('orders');

  // Site Settings State
  const [siteSettings, setSiteSettings] = useState({
    whatsapp: '',
    instagram: '',
    snapchat: '',
    maintenanceMode: false,
    banks: [] as any[]
  });

  const [newBank, setNewBank] = useState({ name: '', iban: '', owner: '' });
  const [isAddingProduct, setIsAddingProduct] = useState(false);

  const isAdmin = user?.email === 'omarmg831@gmail.com';

  useEffect(() => {
    if (!isAdmin) {
      navigate('/');
      return;
    }

    // Load Site Settings
    const loadSettings = () => {
      const savedSettings = JSON.parse(localStorage.getItem('luxe-site-settings') || '{}');
      setSiteSettings({
        whatsapp: savedSettings.whatsapp || '',
        instagram: savedSettings.instagram || '',
        snapchat: savedSettings.snapchat || '',
        maintenanceMode: savedSettings.maintenanceMode || false,
        banks: savedSettings.banks || []
      });
    };
    loadSettings();

    if (isFirebaseConfigured) {
      // Real Firebase Subscriptions
      const qOrders = query(collection(db, "orders"), orderBy("createdAt", "desc"));
      const unsubOrders = onSnapshot(qOrders, (snapshot) => {
        setOrders(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      });

      const qProducts = query(collection(db, "products"));
      const unsubProducts = onSnapshot(qProducts, (snapshot) => {
        setProducts(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
        setLoading(false);
      });

      return () => {
        unsubOrders();
        unsubProducts();
      };
    } else {
      // Local Storage Fallback
      const localOrders = JSON.parse(localStorage.getItem('luxe-orders') || '[]');
      const localProducts = JSON.parse(localStorage.getItem('luxe-products') || '[]');
      setOrders(localOrders);
      setProducts(localProducts);
      setLoading(false);
    }
  }, [isAdmin, navigate]);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem('luxe-site-settings', JSON.stringify(siteSettings));
    toast.success('Site configuration updated');
  };

  const addBank = () => {
    if (!newBank.name || !newBank.iban) return toast.error('Fill bank details');
    const updatedBanks = [...siteSettings.banks, { ...newBank, id: Date.now().toString() }];
    setSiteSettings({ ...siteSettings, banks: updatedBanks });
    setNewBank({ name: '', iban: '', owner: '' });
  };

  const removeBank = (id: string) => {
    setSiteSettings({ ...siteSettings, banks: siteSettings.banks.filter(b => b.id !== id) });
  };

  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    // Local Product State if not defined
    const productForm = (e.target as any);
    const name = productForm.elements.name.value;
    const price = productForm.elements.price.value;
    const tag = productForm.elements.tag.value;
    const imageFile = productForm.elements.image.files[0];

    if (!imageFile || !name || !price) {
      return toast.error('Please fill all fields and upload an image');
    }

    setIsAddingProduct(true);
    const toastId = toast.loading('Adding product...');

    const productData = {
      name: name,
      price: `$${price}`,
      tag: tag,
      rating: 5,
      createdAt: new Date().toISOString()
    };

    try {
      if (isFirebaseConfigured) {
        const storageRef = ref(storage, `products/${Date.now()}_${name}`);
        await uploadBytes(storageRef, imageFile);
        const imageUrl = await getDownloadURL(storageRef);
        await addDoc(collection(db, "products"), { ...productData, image: imageUrl });
      } else {
        // Local Fallback
        const imageUrl = URL.createObjectURL(imageFile);
        const newLocalProduct = { ...productData, id: Math.random().toString(36).substr(2, 9), image: imageUrl };
        const updatedProducts = [...products, newLocalProduct];
        localStorage.setItem('luxe-products', JSON.stringify(updatedProducts));
        setProducts(updatedProducts);
      }

      toast.success('Product added successfully', { id: toastId });
      (e.target as HTMLFormElement).reset();
    } catch (error) {
      toast.error('Failed to add product', { id: toastId });
    } finally {
      setIsAddingProduct(false);
    }
  };

  const deleteProduct = async (id: string) => {
    if (!confirm('Are you sure you want to delete this product?')) return;
    try {
      if (isFirebaseConfigured) {
        await deleteDoc(doc(db, "products", id));
      } else {
        const updatedProducts = products.filter(p => p.id !== id);
        localStorage.setItem('luxe-products', JSON.stringify(updatedProducts));
        setProducts(updatedProducts);
      }
      toast.success('Product deleted');
    } catch (error) {
      toast.error('Failed to delete product');
    }
  };

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
    try {
      if (isFirebaseConfigured) {
        await updateDoc(doc(db, "orders", orderId), { status: newStatus });
      } else {
        const updatedOrders = orders.map(o => o.id === orderId ? { ...o, status: newStatus } : o);
        localStorage.setItem('luxe-orders', JSON.stringify(updatedOrders));
        setOrders(updatedOrders);
      }
      toast.success(`Order ${newStatus} successfully`);
    } catch (error) {
      toast.error('Failed to update status');
    }
  };

  if (!isAdmin) return null;

  return (
    <div className="min-h-screen bg-[#050505] pt-32 pb-20 px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12 gap-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-gold-500 rounded-xl flex items-center justify-center text-black">
              <LayoutDashboard />
            </div>
            <div>
              <h1 className="text-3xl font-serif font-bold">Admin <span className="gold-gradient">Command Center</span></h1>
              <p className="text-gray-500">Managing Luxe Café Global Operations {!isFirebaseConfigured && '(Local Mode)'}</p>
            </div>
          </div>
          <div className="flex gap-4">
            <button 
              onClick={() => setActiveTab('orders')}
              className={`px-6 py-2 rounded-full font-bold transition-all ${activeTab === 'orders' ? 'bg-gold-500 text-black' : 'border border-white/10 text-white hover:bg-white/5'}`}
            >
              Orders
            </button>
            <button 
              onClick={() => setActiveTab('products')}
              className={`px-6 py-2 rounded-full font-bold transition-all ${activeTab === 'products' ? 'bg-gold-500 text-black' : 'border border-white/10 text-white hover:bg-white/5'}`}
            >
              Products
            </button>
            <button 
              onClick={() => setActiveTab('settings')}
              className={`px-6 py-2 rounded-full font-bold transition-all ${activeTab === 'settings' ? 'bg-gold-500 text-black' : 'border border-white/10 text-white hover:bg-white/5'}`}
            >
              Site Settings
            </button>
            <button onClick={() => navigate('/')} className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors ml-4">
              <ArrowLeft className="w-4 h-4" />
              Site
            </button>
          </div>
        </div>

        {activeTab === 'orders' ? (
          <>
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              <div className="glass-card p-6 border-gold-500/20 bg-gold-500/5">
                <div className="flex justify-between items-start mb-4">
                  <ShoppingBag className="text-gold-500" />
                  <span className="text-xs font-bold text-gold-500 bg-gold-500/10 px-2 py-1 rounded">Total Orders</span>
                </div>
                <p className="text-4xl font-serif font-bold">{orders.length}</p>
              </div>
              <div className="glass-card p-6">
                <div className="flex justify-between items-start mb-4">
                  <Clock className="text-blue-400" />
                  <span className="text-xs font-bold text-blue-400 bg-blue-400/10 px-2 py-1 rounded">Pending</span>
                </div>
                <p className="text-4xl font-serif font-bold">{orders.filter(o => o.status === 'pending').length}</p>
              </div>
              <div className="glass-card p-6">
                <div className="flex justify-between items-start mb-4">
                  <Users className="text-purple-400" />
                  <span className="text-xs font-bold text-purple-400 bg-purple-400/10 px-2 py-1 rounded">Customers</span>
                </div>
                <p className="text-4xl font-serif font-bold">{new Set(orders.map(o => o.userId)).size}</p>
              </div>
            </div>

            {/* Orders Table */}
            <div className="glass-card overflow-hidden">
              <div className="p-6 border-b border-white/5 bg-white/5">
                <h3 className="font-bold uppercase tracking-widest text-sm">Recent Transactions</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="text-xs uppercase tracking-widest text-gray-500 border-b border-white/5">
                      <th className="px-6 py-4 font-medium">Customer</th>
                      <th className="px-6 py-4 font-medium">Items</th>
                      <th className="px-6 py-4 font-medium">Total</th>
                      <th className="px-6 py-4 font-medium">Payment</th>
                      <th className="px-6 py-4 font-medium">Status</th>
                      <th className="px-6 py-4 font-medium text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {orders.map((order) => (
                      <tr key={order.id} className="hover:bg-white/5 transition-colors group">
                        <td className="px-6 py-4">
                          <div className="font-bold">{order.userName}</div>
                          <div className="text-xs text-gray-500">{order.userEmail}</div>
                        </td>
                        <td className="px-6 py-4">
                          {order.items?.map((item: any, i: number) => (
                            <div key={i} className="text-sm">{item.name} x{item.quantity}</div>
                          ))}
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-gold-500 font-bold">${order.total?.toFixed(2)}</span>
                        </td>
                        <td className="px-6 py-4">
                          <a 
                            href={order.receiptUrl} 
                            target="_blank" 
                            rel="noreferrer"
                            className="flex items-center gap-2 text-xs text-blue-400 hover:underline"
                          >
                            View Receipt <ExternalLink className="w-3 h-3" />
                          </a>
                          <div className="text-[10px] text-gray-500 mt-1">{order.bankName}</div>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`text-[10px] uppercase font-bold px-2 py-1 rounded ${
                            order.status === 'pending' ? 'bg-yellow-500/10 text-yellow-500' :
                            order.status === 'approved' ? 'bg-green-500/10 text-green-500' : 'bg-red-500/10 text-red-500'
                          }`}>
                            {order.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex justify-end gap-2">
                            <button 
                              onClick={() => updateOrderStatus(order.id, 'approved')}
                              className="p-2 bg-green-500/10 text-green-500 rounded-lg hover:bg-green-500 hover:text-white transition-all"
                            >
                              <CheckCircle className="w-4 h-4" />
                            </button>
                            <button 
                              onClick={() => updateOrderStatus(order.id, 'rejected')}
                              className="p-2 bg-red-500/10 text-red-500 rounded-lg hover:bg-red-500 hover:text-white transition-all"
                            >
                              <XCircle className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        ) : activeTab === 'products' ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Add Product Form */}
            <div className="lg:col-span-1">
              <div className="glass-card p-8 sticky top-32">
                <h3 className="text-xl font-serif font-bold mb-6 flex items-center gap-2">
                  <Plus className="text-gold-500" /> Add New Blend
                </h3>
                <form onSubmit={handleAddProduct} className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-widest text-gray-500">Blend Name</label>
                    <input 
                      type="text" 
                      name="name"
                      required
                      value={newProduct.name}
                      onChange={e => setNewProduct({...newProduct, name: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:border-gold-500 outline-none" 
                      placeholder="e.g. Ethiopian Gold"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-widest text-gray-500">Price ($)</label>
                    <input 
                      type="number" 
                      name="price"
                      required
                      value={newProduct.price}
                      onChange={e => setNewProduct({...newProduct, price: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:border-gold-500 outline-none" 
                      placeholder="45.00"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-widest text-gray-500">Roast Type</label>
                    <select 
                      name="tag"
                      value={newProduct.tag}
                      onChange={e => setNewProduct({...newProduct, tag: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:border-gold-500 outline-none"
                    >
                      <option value="Dark Roast">Dark Roast</option>
                      <option value="Medium Roast">Medium Roast</option>
                      <option value="Light Roast">Light Roast</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-widest text-gray-500">Product Image</label>
                    <div className="relative border-2 border-dashed border-white/10 rounded-xl p-4 text-center hover:border-gold-500/50 transition-all">
                      <input 
                        type="file" 
                        name="image"
                        required
                        onChange={e => setNewProduct({...newProduct, image: e.target.files?.[0] || null})}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
                      />
                      <Upload className="w-6 h-6 mx-auto mb-2 text-gray-500" />
                      <p className="text-xs text-gray-500">{newProduct.image ? newProduct.image.name : 'Upload image'}</p>
                    </div>
                  </div>
                  <button 
                    disabled={isAddingProduct}
                    className="w-full btn-gold py-4 mt-4 disabled:opacity-50 flex justify-center items-center gap-2"
                  >
                    {isAddingProduct ? <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin" /> : <Package className="w-5 h-5" />}
                    Add Product
                  </button>
                </form>
              </div>
            </div>

            {/* Product List */}
            <div className="lg:col-span-2">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {products.map((product) => (
                  <div key={product.id} className="glass-card overflow-hidden group">
                    <div className="aspect-video relative">
                      <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                      <div className="absolute top-4 right-4 flex gap-2">
                        <button 
                          onClick={() => deleteProduct(product.id)}
                          className="p-2 bg-red-500/20 text-red-500 backdrop-blur-md rounded-lg hover:bg-red-500 hover:text-white transition-all"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                    <div className="p-6">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-bold text-lg">{product.name}</h4>
                        <span className="text-gold-500 font-bold">{product.price}</span>
                      </div>
                      <span className="text-[10px] uppercase tracking-widest text-gray-500 bg-white/5 px-2 py-1 rounded">
                        {product.tag}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              {products.length === 0 && (
                <div className="p-20 text-center opacity-30 border-2 border-dashed border-white/10 rounded-3xl">
                  <Package className="w-12 h-12 mx-auto mb-4" />
                  <p>No products added yet</p>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="max-w-4xl mx-auto">
            <div className="glass-card p-10">
              <h3 className="text-2xl font-serif font-bold mb-8 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Settings className="text-gold-500" /> General Site Configuration
                </div>
                <div className="flex items-center gap-3 bg-white/5 px-4 py-2 rounded-xl border border-white/10">
                  <span className="text-sm font-bold uppercase tracking-widest text-gray-400">Maintenance</span>
                  <button 
                    onClick={() => setSiteSettings({...siteSettings, maintenanceMode: !siteSettings.maintenanceMode})}
                    className={`w-12 h-6 rounded-full relative transition-colors ${siteSettings.maintenanceMode ? 'bg-red-500' : 'bg-gray-700'}`}
                  >
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${siteSettings.maintenanceMode ? 'left-7' : 'left-1'}`} />
                  </button>
                </div>
              </h3>
              
              <form onSubmit={handleSaveSettings} className="space-y-8">
                {/* Social Links */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-widest text-gray-500">WhatsApp Number</label>
                    <input 
                      type="text" 
                      value={siteSettings.whatsapp}
                      onChange={e => setSiteSettings({...siteSettings, whatsapp: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:border-gold-500 outline-none" 
                      placeholder="+966500000000"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-widest text-gray-500">Instagram Profile</label>
                    <input 
                      type="text" 
                      value={siteSettings.instagram}
                      onChange={e => setSiteSettings({...siteSettings, instagram: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:border-gold-500 outline-none" 
                      placeholder="username"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-widest text-gray-500">Snapchat Username</label>
                    <input 
                      type="text" 
                      value={siteSettings.snapchat}
                      onChange={e => setSiteSettings({...siteSettings, snapchat: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:border-gold-500 outline-none" 
                      placeholder="username"
                    />
                  </div>
                </div>

                {/* Bank Details */}
                <div className="pt-6 border-t border-white/5 space-y-6">
                  <h4 className="text-lg font-bold">Bank Accounts (Checkout Options)</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <input 
                      type="text" 
                      placeholder="Bank Name" 
                      value={newBank.name}
                      onChange={e => setNewBank({...newBank, name: e.target.value})}
                      className="bg-white/5 border border-white/10 rounded-xl px-4 py-2 focus:border-gold-500 outline-none text-sm"
                    />
                    <input 
                      type="text" 
                      placeholder="IBAN" 
                      value={newBank.iban}
                      onChange={e => setNewBank({...newBank, iban: e.target.value})}
                      className="bg-white/5 border border-white/10 rounded-xl px-4 py-2 focus:border-gold-500 outline-none text-sm font-mono"
                    />
                    <div className="flex gap-2">
                      <input 
                        type="text" 
                        placeholder="Owner" 
                        value={newBank.owner}
                        onChange={e => setNewBank({...newBank, owner: e.target.value})}
                        className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-2 focus:border-gold-500 outline-none text-sm"
                      />
                      <button 
                        type="button" 
                        onClick={addBank}
                        className="bg-gold-500 text-black p-2 rounded-xl hover:bg-gold-400"
                      >
                        <Plus className="w-5 h-5" />
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-3">
                    {siteSettings.banks.map((bank: any) => (
                      <div key={bank.id} className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-white/10">
                        <div className="flex gap-6">
                          <div><span className="text-[10px] text-gray-500 block">Bank</span>{bank.name}</div>
                          <div><span className="text-[10px] text-gray-500 block">IBAN</span>{bank.iban}</div>
                          <div><span className="text-[10px] text-gray-500 block">Owner</span>{bank.owner}</div>
                        </div>
                        <button 
                          type="button" 
                          onClick={() => removeBank(bank.id)}
                          className="text-red-500 hover:bg-red-500/10 p-2 rounded-lg"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                <button 
                  type="submit"
                  className="w-full btn-gold py-5 text-lg shadow-xl"
                >
                  Save Global Settings
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;
