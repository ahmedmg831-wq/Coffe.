import React, { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ShoppingCart, Star, Plus, Coffee } from 'lucide-react';
import { useCart } from '../store/useCart';
import { useAuth } from '../store/useAuth';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { db, isFirebaseConfigured } from '../lib/firebase';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';

gsap.registerPlugin(ScrollTrigger);

const ProductShowcase = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const { addItem } = useCart();
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isFirebaseConfigured) {
      const q = query(collection(db, "products"), orderBy("createdAt", "desc"));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const productsData = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        }));
        setProducts(productsData);
        setLoading(false);
      }, (error) => {
        console.warn("Firestore access denied. Using fallback data.");
        setLoading(false);
      });
      return () => unsubscribe();
    } else {
      // Local Fallback
      const localProducts = JSON.parse(localStorage.getItem('luxe-products') || '[]');
      setProducts(localProducts);
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (products.length > 0) {
      const ctx = gsap.context(() => {
        gsap.from(".product-card", {
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top 70%",
          },
          y: 50,
          opacity: 0,
          duration: 1,
          stagger: 0.2,
          ease: "power4.out"
        });
      }, sectionRef);
      return () => ctx.revert();
    }
  }, [products]);

  const handleAddToCart = (product: any) => {
    if (!isAuthenticated) {
      toast.error('Please join the Elite Circle to purchase', {
        style: { background: '#171717', color: '#ff4b4b' }
      });
      navigate('/auth');
      return;
    }
    
    addItem(product);
    toast.success(`${product.name} added to selection`, {
      style: {
        background: '#171717',
        color: '#d4af37',
        border: '1px solid rgba(212, 175, 55, 0.2)',
      },
      icon: <Plus className="w-4 h-4" />,
    });
  };

  return (
    <section ref={sectionRef} id="products" className="py-24 px-8 bg-neutral-950">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div>
            <h2 className="text-gold-500 font-serif italic text-xl mb-4">Our Signature Collection</h2>
            <h3 className="text-4xl md:text-5xl font-serif font-bold">The Connoisseur's Choice</h3>
          </div>
          <button className="text-gold-500 font-bold border-b-2 border-gold-500 pb-1 hover:text-gold-400 hover:border-gold-400 transition-colors">
            View All Products
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {products.length > 0 ? (
            products.map((product) => (
              <div key={product.id} className="product-card group relative">
                <div className="relative aspect-[4/5] overflow-hidden rounded-2xl">
                  <img 
                    src={product.image} 
                    alt={product.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-end p-8">
                    <button 
                      onClick={() => handleAddToCart(product)}
                      className="w-full bg-gold-500 text-black py-4 rounded-xl font-bold flex items-center justify-center gap-2 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500"
                    >
                      <ShoppingCart className="w-5 h-5" />
                      Add to Cart
                    </button>
                  </div>
                  <div className="absolute top-4 left-4 glass-card px-3 py-1 text-xs uppercase tracking-widest">
                    {product.tag}
                  </div>
                </div>
                
                <div className="mt-6 flex justify-between items-start">
                  <div>
                    <h4 className="text-xl font-bold mb-2">{product.name}</h4>
                    <div className="flex items-center gap-1">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-gold-500 text-gold-500" />
                      ))}
                      <span className="text-sm text-gray-400 ml-2">5.0</span>
                    </div>
                  </div>
                  <p className="text-2xl font-serif text-gold-500 font-bold">{product.price}</p>
                </div>
              </div>
            ))
          ) : (
            !loading && [1, 2, 3].map((i) => (
              <div key={i} className="product-card group relative opacity-20">
                <div className="relative aspect-[4/5] overflow-hidden rounded-2xl bg-white/5 flex flex-col items-center justify-center border border-white/10">
                  <Coffee className="w-12 h-12 mb-4" />
                  <p className="text-xs uppercase tracking-widest">Awaiting Stock</p>
                </div>
              </div>
            ))
          )}
        </div>
        {loading && (
          <div className="flex justify-center py-20">
            <div className="w-10 h-10 border-4 border-gold-500 border-t-transparent rounded-full animate-spin" />
          </div>
        )}
      </div>
    </section>
  );
};

export default ProductShowcase;
