import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

// These should be in a .env file for a real production app
const firebaseConfig = {
  apiKey: (import.meta as any).env?.VITE_FIREBASE_API_KEY || "YOUR_API_KEY",
  authDomain: (import.meta as any).env?.VITE_FIREBASE_AUTH_DOMAIN || "your-app.firebaseapp.com",
  projectId: (import.meta as any).env?.VITE_FIREBASE_PROJECT_ID || "your-app",
  storageBucket: (import.meta as any).env?.VITE_FIREBASE_STORAGE_BUCKET || "your-app.appspot.com",
  messagingSenderId: (import.meta as any).env?.VITE_FIREBASE_MESSAGING_SENDER_ID || "123456789",
  appId: (import.meta as any).env?.VITE_FIREBASE_APP_ID || "1:123456789:web:abcdef"
};

// Check if Firebase is properly configured
export const isFirebaseConfigured = 
  firebaseConfig.apiKey !== "YOUR_API_KEY" && 
  firebaseConfig.apiKey.length > 10;

// Initialize Firebase only if configured, otherwise provide dummy objects
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = isFirebaseConfigured ? getFirestore(app) : (null as any);
export const storage = isFirebaseConfigured ? getStorage(app) : (null as any);
